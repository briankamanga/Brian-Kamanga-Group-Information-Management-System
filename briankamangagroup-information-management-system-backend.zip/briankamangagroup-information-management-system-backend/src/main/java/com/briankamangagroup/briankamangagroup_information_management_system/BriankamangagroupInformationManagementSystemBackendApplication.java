package com.briankamangagroup.briankamangagroup_information_management_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BriankamangagroupInformationManagementSystemBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BriankamangagroupInformationManagementSystemBackendApplication.class, args);
	}

}
